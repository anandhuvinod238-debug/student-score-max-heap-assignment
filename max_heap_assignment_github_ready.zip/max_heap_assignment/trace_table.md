# Trace Table

| Step | Inserted Score | Heap Arrangement After Insertion | Comparisons |
|---:|---:|---|---:|
| 1 | 78 | 78 | 0 |
| 2 | 92 | 92, 78 | 1 |
| 3 | 65 | 92, 78, 65 | 1 |
| 4 | 88 | 92, 88, 65, 78 | 1 |
| 5 | 95 | 95, 92, 65, 78, 88 | 2 |
| 6 | 72 | 95, 92, 72, 78, 88, 65 | 1 |
| 7 | 84 | 95, 92, 84, 78, 88, 65, 72 | 1 |
| 8 | 90 | 95, 92, 90, 78, 88, 65, 72, 84 | 1 |

**Total insertion comparisons = 8.**

For finding the maximum:
- **Max Heap:** maximum is at the root, so 1 root-access operation.
- **Linear Search:** 7 comparisons are required for 8 scores.
