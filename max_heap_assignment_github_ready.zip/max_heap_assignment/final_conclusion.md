# Final Conclusion

The given scores are `78, 92, 65, 88, 95, 72, 84, 90`. After all insertions, the Max Heap becomes:

`95, 92, 90, 78, 88, 65, 72, 84`

The highest score is **95**. The Max Heap finds it directly from the root with one root-access operation, whereas Linear Search checks the remaining elements sequentially and requires **7 comparisons** for these 8 scores.

For insertion, a Max Heap requires **O(log n)** time in the worst case because the new element may move upward. Linear Search itself is a searching method rather than an insertion structure; an unsorted array can append a new score in **O(1)** time. If only the current highest score must be maintained, an additional `currentMax` variable can make both insertion and maximum lookup O(1).

Thus, **among the two approaches specified in the assignment, the Max Heap is more suitable when the system repeatedly needs the highest student score**, because the maximum is always available at the root and remains O(1) to retrieve as the number of students grows. For the narrower requirement of only inserting scores and tracking one maximum, a separate maximum variable is even simpler.
