# Complexity Analysis

| Operation | Max Heap | Linear Search / Unsorted Array |
|---|---|---|
| Find maximum | **O(1)** | **O(n)** |
| Insert a new score | **O(log n)** | **O(1)** to append; **O(1)** extra comparison to maintain a separate maximum |
| Find maximum after each insertion | **O(1)** | **O(1)** if the current maximum is maintained; otherwise O(n) |
| Build structure by repeated insertion | **O(n log n)** | O(n) to read/append |
| Space | **O(n)** | **O(n)** |

### Important interpretation

If the requirement is specifically to maintain the highest score continuously, a Max Heap is a suitable choice **among the two requested approaches**, especially when later operations may also need heap functionality such as repeatedly removing the highest score.

However, if the only requirement is:
1. insert scores, and
2. always know the current highest score,

then keeping a separate `currentMax` variable with the unsorted collection gives **O(1) insertion and O(1) maximum lookup**. That is simpler than a heap for this narrow requirement.
