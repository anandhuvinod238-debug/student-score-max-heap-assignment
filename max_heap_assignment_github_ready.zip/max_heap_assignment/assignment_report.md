# Max Heap and Linear Search — Assignment Report

## 1. Given Data
78, 92, 65, 88, 95, 72, 84, 90

## 2. Max Heap Insertion
The heap after each insertion is documented in `trace_table.md`.

Final heap:
**95, 92, 90, 78, 88, 65, 72, 84**

## 3. Maximum Search
- Max Heap: **95**, using **1 root-access operation**.
- Linear Search: **95**, using **7 comparisons**.

## 4. Complexity
- Max Heap maximum: **O(1)**
- Max Heap insertion: **O(log n)**
- Linear Search maximum: **O(n)**
- Unsorted-array append: **O(1)**

## 5. Performance Comparison
See `comparison_table.md`.

## 6. Conclusion
See `final_conclusion.md`.
