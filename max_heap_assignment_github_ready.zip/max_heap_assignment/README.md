# Student Score Max Heap Assignment

## Problem
A university wants to identify the highest student score from:

`78, 92, 65, 88, 95, 72, 84, 90`

## Objectives
- Implement a Max Heap in C.
- Record the heap after every insertion.
- Find the maximum using Max Heap and Linear Search.
- Count comparisons/operations.
- Compare performance, time complexity and space complexity.
- Justify the suitable approach for continuously maintaining the highest score.

## Repository Contents
- `max_heap.c` — C source code.
- `input.txt` — given input data.
- `output.txt` — execution output.
- `trace_table.md` — insertion trace table.
- `comparison_table.md` — performance comparison.
- `complexity_analysis.md` — time and space complexity.
- `final_conclusion.md` — final conclusion.

## Execution
Compile:
```bash
gcc max_heap.c -o max_heap
```

Run:
```bash
./max_heap
```

On Windows:
```bash
gcc max_heap.c -o max_heap.exe
max_heap.exe
```

## Result
Final Max Heap:
`95 92 90 78 88 65 72 84`

Highest score:
`95`

Max Heap maximum retrieval:
`1 root-access operation`

Linear Search:
`7 comparisons`

## Note
For a system that only needs to insert scores and maintain one highest value, a separate `currentMax` variable can achieve O(1) insertion and O(1) maximum lookup. The Max Heap is preferable among the two specified approaches when repeated highest-element operations are the main requirement or when future heap operations are needed.
