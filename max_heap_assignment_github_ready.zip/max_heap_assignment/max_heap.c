#include <stdio.h>

#define MAX 100

int heap[MAX];
int size = 0;

void displayHeap(void) {
    for (int i = 0; i < size; i++)
        printf("%d ", heap[i]);
    printf("\n");
}

int insertHeap(int value) {
    int i = size;
    int comparisons = 0;
    heap[size++] = value;

    while (i > 0) {
        int parent = (i - 1) / 2;
        comparisons++;
        if (heap[parent] >= heap[i])
            break;

        int temp = heap[parent];
        heap[parent] = heap[i];
        heap[i] = temp;
        i = parent;
    }
    return comparisons;
}

int findMaxHeap(int *operations) {
    *operations = 1;   // Accessing the root
    return heap[0];
}

int linearSearchMax(int a[], int n, int *comparisons) {
    int max = a[0];
    *comparisons = 0;

    for (int i = 1; i < n; i++) {
        (*comparisons)++;
        if (a[i] > max)
            max = a[i];
    }
    return max;
}

int main(void) {
    int scores[] = {78, 92, 65, 88, 95, 72, 84, 90};
    int n = sizeof(scores) / sizeof(scores[0]);
    int totalHeapComparisons = 0;

    printf("MAX HEAP INSERTION TRACE\n");
    printf("========================\n");

    for (int i = 0; i < n; i++) {
        int c = insertHeap(scores[i]);
        totalHeapComparisons += c;
        printf("Insert %d -> Heap: ", scores[i]);
        displayHeap();
        printf("Comparisons for insertion: %d\n\n", c);
    }

    int heapOps;
    int heapMax = findMaxHeap(&heapOps);

    int linearComparisons;
    int linearMax = linearSearchMax(scores, n, &linearComparisons);

    printf("MAXIMUM SEARCH\n");
    printf("==============\n");
    printf("Max Heap: Maximum = %d, Operations = %d\n", heapMax, heapOps);
    printf("Linear Search: Maximum = %d, Comparisons = %d\n",
           linearMax, linearComparisons);

    printf("\nTOTAL HEAP INSERTION COMPARISONS = %d\n", totalHeapComparisons);
    return 0;
}
