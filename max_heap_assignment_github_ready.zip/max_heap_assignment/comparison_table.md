# Performance Comparison

| Criterion | Max Heap | Linear Search |
|---|---|---|
| Maximum for 8 scores | 1 root-access operation | 7 comparisons |
| Maximum for n scores | O(1) | O(n) |
| New-score insertion | O(log n) worst case | O(1) append |
| Maintaining current maximum | Root always stores maximum | Requires scanning if no max variable is stored |
| Growth with number of students | Maximum lookup remains O(1) | Maximum lookup grows linearly |
| Main advantage | Fast maximum retrieval | Very simple implementation |
| Main limitation | More work during insertion | Repeated maximum searches are expensive |

### Example of inserting a new score

For an illustrative new score of **97**:
- In the existing Max Heap, 97 must move upward to restore heap order; this takes at most **O(log n)** comparisons.
- In an unsorted array, 97 can be appended in **O(1)** time. If a separate current-maximum variable is maintained, only one comparison is needed to update it.

Therefore, the choice depends on the workload. For repeated highest-element retrieval, the Max Heap provides O(1) maximum access and O(log n) insertion.
